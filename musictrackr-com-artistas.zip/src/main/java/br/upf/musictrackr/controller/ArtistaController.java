package br.upf.musictrackr.controller;

import br.upf.musictrackr.entity.ArtistaEntity;
import br.upf.musictrackr.facade.ArtistaFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.util.List;

@Named
@RequestScoped
public class ArtistaController {

    @EJB
    private ArtistaFacade facade;

    private ArtistaEntity entidade = new ArtistaEntity();

    public List<ArtistaEntity> getListarTodos() {
        return facade.findAll();
    }

    public String inserir() {
        facade.create(entidade);
        entidade = new ArtistaEntity();
        return null;
    }

    public String alterar() {
        facade.edit(entidade);
        entidade = new ArtistaEntity();
        return null;
    }

    public String excluir(ArtistaEntity e) {
        facade.remove(e);
        return null;
    }

    public ArtistaEntity getEntidade() {
        return entidade;
    }

    public void setEntidade(ArtistaEntity entidade) {
        this.entidade = entidade;
    }
}
